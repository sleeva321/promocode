package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Promocode;
import com.cg.dao.IPromoDao;

@Service
@Transactional
public class AdminServicesImpl implements AdminServices {
@Autowired
		IPromoDao promoDao;
		
		@Override
		public void addPromo(Promocode promo) {
			// TODO Auto-generated method stub
			promoDao.save(promo);	
			
		}

		@Override
		public List<Promocode> getAllPromos() {
			// TODO Auto-generated method stub
			return promoDao.findAll();
		}
}
