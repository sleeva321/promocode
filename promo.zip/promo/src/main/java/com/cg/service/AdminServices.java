package com.cg.service;

import java.util.List;

import com.cg.bean.Promocode;

public interface AdminServices {
	public void addPromo(Promocode promo);
	public List<Promocode> getAllPromos();
}
