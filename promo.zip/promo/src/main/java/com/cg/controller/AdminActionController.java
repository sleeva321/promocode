package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Promocode;
import com.cg.service.AdminServices;
@CrossOrigin()
@RestController

public class AdminActionController {
	@Autowired
	private AdminServices adminService;
	@GetMapping("/AllPromocodes") // Get mapping for getting list of sessions
	public List<Promocode>  getAllPromos() {
		return adminService. getAllPromos();
	}
	
	@PostMapping(value = "/addPromocode", consumes = { "application/json" }) // to add session into the database
	public String save(@RequestBody Promocode p) {
		adminService.addPromo(p);
		return "Promo added!";
	}
	
}
